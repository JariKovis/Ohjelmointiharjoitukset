
public class Ohjelma {

    public static void main(String[] args) {
        // Testaa ohjelmaasi täällä
//        Kellari kellari = new Kellari();
//        kellari.lisaa("a14", "luistimet");
//        kellari.lisaa("a14", "maila");
//        kellari.lisaa("a14", "luistimet");
//
//        kellari.lisaa("f156", "rullaluistimet");
//        kellari.lisaa("f156", "rullaluistimet");
//
//        kellari.lisaa("g63", "six");
//        kellari.lisaa("g63", "pi");
//
//        kellari.poista("f156", "rullaluistimet");
//
//        System.out.println(kellari.sisalto("f156"));
//        System.out.println(kellari.komerot());

    }
}
