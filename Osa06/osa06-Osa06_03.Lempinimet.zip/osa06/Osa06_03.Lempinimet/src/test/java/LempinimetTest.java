
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.*;

@Points("06-03")
public class LempinimetTest {

    @Test
    public void eiTesteja() throws Exception {
        // ei testejä

    }

}
