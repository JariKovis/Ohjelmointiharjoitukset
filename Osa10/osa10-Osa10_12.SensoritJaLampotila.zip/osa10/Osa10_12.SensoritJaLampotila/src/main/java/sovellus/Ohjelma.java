package sovellus;

public class Ohjelma {

    public static void main(String[] args) {
        // voit testata luokkiasi täällä
    }

}
