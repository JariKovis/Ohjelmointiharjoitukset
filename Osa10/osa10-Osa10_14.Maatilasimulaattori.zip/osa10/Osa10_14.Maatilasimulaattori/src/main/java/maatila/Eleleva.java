package maatila;

public interface Eleleva {

    void eleleTunti();
}
