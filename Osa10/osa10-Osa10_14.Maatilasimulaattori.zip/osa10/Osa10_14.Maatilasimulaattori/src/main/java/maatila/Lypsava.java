package maatila;

public interface Lypsava {

    double lypsa();
}
