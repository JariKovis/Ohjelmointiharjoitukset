
import java.util.Scanner;

public class Ohjelma {

    public static void main(String[] args) {
        // Voit kokeilla ohjelmasi toimintaa täällä


    }
}
