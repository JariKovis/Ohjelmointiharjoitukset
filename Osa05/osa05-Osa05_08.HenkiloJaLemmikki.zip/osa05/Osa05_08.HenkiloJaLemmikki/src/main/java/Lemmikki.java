
public class Lemmikki {

    private String nimi;
    private String rotu;

    public Lemmikki(String nimi, String rotu) {
        this.nimi = nimi;
        this.rotu = rotu;
    }

    public String getNimi() {
        return nimi;
    }

    public String getRotu() {
        return rotu;
    }

}
