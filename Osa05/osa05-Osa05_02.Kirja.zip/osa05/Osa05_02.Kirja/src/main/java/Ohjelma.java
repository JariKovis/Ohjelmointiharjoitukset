
public class Ohjelma {

    public static void main(String[] args) {
        // Tämä on vain tyhjä main-metodi jossa voit kokeilla
        // Kirja-luokkaasi. Kokeile esim:

//        Kirja k = new Kirja("J. K. Rowling", "Harry Potter ja viisasten kivi", 223);
//        System.out.println(k);

    }
}
