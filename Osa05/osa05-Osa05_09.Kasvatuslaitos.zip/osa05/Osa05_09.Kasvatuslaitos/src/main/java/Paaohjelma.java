
public class Paaohjelma {

    public static void main(String[] args) {
        // kirjoita tänne testikoodia 
    }
}
