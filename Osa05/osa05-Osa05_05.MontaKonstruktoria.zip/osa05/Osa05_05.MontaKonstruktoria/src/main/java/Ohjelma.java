
public class Ohjelma {

    public static void main(String[] args) {
        // tee tänne testikoodia
    }
}
