package piirturi;


import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("14-01")
public class PiirtoOhjelmaTest {

    @Test
    public void eiTesteja() {

    }

}
