package testausta;

import java.util.Scanner;

public class Ohjelma {

    public static void main(String[] args) {
        Scanner lukija = new Scanner(System.in);
        suorita(lukija);
    }

    public static String suorita(Scanner lukija) {
        return "";
    }
}
