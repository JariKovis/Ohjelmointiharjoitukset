package testausta;

public class OhjelmaTest {

    // toteuta tänne testit luokkaa Ohjelma-varten
}
