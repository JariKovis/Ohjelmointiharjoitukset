package hiekkaranta;


public class Simulaatio {

    public Simulaatio(int leveys, int korkeus) {
    }

    public void lisaa(int x, int y, Tyyppi tyyppi) {
    }

    public Tyyppi sisalto(int x, int y) {
        return Tyyppi.METALLI;
    }

    public void paivita() {
    }

}
