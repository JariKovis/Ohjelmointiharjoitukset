

public class Paaohjelma {

    public static void main(String[] args) {
        // tee tänne testikoodia

    }

    // toteuta tänne metodi palautaKoko, joka palauttaa parametrina 
    // saamansa set-olion alkioiden lukumäärän

}
