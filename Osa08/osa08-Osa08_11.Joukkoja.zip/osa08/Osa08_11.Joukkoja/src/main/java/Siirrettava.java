

public interface Siirrettava {

    void siirra(int dx, int dy);
}
