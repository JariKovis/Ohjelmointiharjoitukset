
public interface Palvelusvelvollinen {

    int paiviaJaljella();

    void palvele();
}
