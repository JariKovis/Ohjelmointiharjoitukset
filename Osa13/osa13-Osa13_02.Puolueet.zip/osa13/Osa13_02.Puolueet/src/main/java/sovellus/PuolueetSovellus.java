package sovellus;

public class PuolueetSovellus {

    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

}
