package asteroids;

public class AsteroidsSovellus {

    public static void main(String[] args) {
        System.out.println("Hei maailma!");
    }

    public static int osiaToteutettu() {
        // Ilmoita tämän metodin palautusarvolla kuinka monta osaa olet tehnyt
        return 0;
    }

}
