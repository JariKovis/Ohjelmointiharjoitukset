package hymio;


public class HymioSovellus {


    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

}
