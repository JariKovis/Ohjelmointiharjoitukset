package sovellus;

import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("13-04")
public class EpareiluaMainontaaSovellusTest {

    @Test
    public void noTests() {

    }
}
