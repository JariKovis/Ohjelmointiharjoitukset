
public class Main {

    public static void main(String[] args) {
        // Tämä on vain tyhjä main-metodi jossa voit kokeilla
        // Pilli-luokkaasi. Kokeile esim:

//        Pilli sorsapilli = new Pilli("Kvaak");
//        Pilli kukkopilli = new Pilli("Peef");
//
//        sorsapilli.soi();
//        kukkopilli.soi();
//        sorsapilli.soi();
    }
}
