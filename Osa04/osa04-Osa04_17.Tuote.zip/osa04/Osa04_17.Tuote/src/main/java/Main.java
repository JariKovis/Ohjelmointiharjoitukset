
public class Main {

    public static void main(String[] args) {
        // Tämä on vain tyhjä main-metodi jossa voit kokeilla
        // Tuote-luokkaasi. Kokeile esim:

        // Tuote tuote = new Tuote("Banaani", 1.1, 13);
        // tuote.tulostaTuote();
    }
}
