
public class Main {

    public static void main(String[] args) {
        // Tämä on vain tyhjä main-metodi jossa voit kokeilla
        // Ovi-luokkaasi. Kokeile esim:

//        Ovi alexander = new Ovi();
//
//        alexander.koputa();
//        alexander.koputa();
    }
}
