
public class Lukutilasto {
}
