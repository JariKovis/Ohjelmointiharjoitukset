
public class Main {

    public static void main(String[] args) {
        // Tämä on vain tyhjä main-metodi jossa voit kokeilla luokkasi toimintaa.
        // esimerkiksi: 

        // Kertoja kolmellaKertoja = new Kertoja(3);
        // System.out.println(kolmellaKertoja.kerro(5));
    }
}
