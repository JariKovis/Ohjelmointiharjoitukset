
public class Paaohjelma {

    public static void main(String[] args) {
        VahenevaLaskuri laskuri = new VahenevaLaskuri(10);

        laskuri.tulostaArvo();
        laskuri.vahene();
        laskuri.vahene();
    }
}
