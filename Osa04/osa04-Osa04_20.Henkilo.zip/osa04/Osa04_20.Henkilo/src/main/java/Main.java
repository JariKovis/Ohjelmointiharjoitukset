
public class Main {

    public static void main(String[] args) {
        // Tämä on vain tyhjä main-metodi jossa voit kokeilla
        // Henkilo-luokkaasi. Kokeile esim:

//        Henkilo lilja = new Henkilo("Lilja");
//        Henkilo antti = new Henkilo("Antti");
//
//        antti.tulostaHenkilo();
//
//        lilja.vanhene();
//        lilja.vanhene();
//
//        antti.vanhene();
//
//        System.out.println("Lilja ikä: " + lilja.palautaIka());
//        System.out.println("Antin ikä: " + antti.palautaIka());
//
//        int yht = lilja.palautaIka() + antti.palautaIka();
//
//        System.out.println("Lilja ja Antti yhteensä " + yht + " vuotta");
    }
}
