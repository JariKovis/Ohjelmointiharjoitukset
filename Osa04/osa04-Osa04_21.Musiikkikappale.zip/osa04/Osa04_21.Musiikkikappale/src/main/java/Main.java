
public class Main {

    public static void main(String[] args) {
        // Tämä on vain tyhjä main-metodi jossa voit kokeilla
        // Musiikkikappale-luokkaasi. Kokeile esim:
        
//        Musiikkikappale garden = new Musiikkikappale("In The Garden", 10910);
//        System.out.println("Kappaleen " + garden.nimi() + " pituus on " + garden.pituus() + " sekuntia.");
    }
}
