
public class OlipaKerranMaa {

    public static void main(String[] args) {
        // Toteuta ohjelmasi tänne
    }
}
