
import java.util.Scanner;

public class MuuttuvatMuuttujat {

    public static void main(String[] args) {
        // MUUTA NÄITÄ:

        int kanojenLkm = 3;
        double pekoninPaino = 5.5;
        String traktori = "Ei ole!";

        // ÄLÄ MUUTA NÄITÄ:
        System.out.println("Kanoja:");
        System.out.println(kanojenLkm);
        System.out.println("Pekonia (kg):");
        System.out.println(pekoninPaino);
        System.out.println("Traktori:");
        System.out.println(traktori);
        System.out.println("");
        System.out.println("Tässä vielä tiivistelmä:");
        System.out.println(kanojenLkm);
        System.out.println(pekoninPaino);
        System.out.println(traktori);
    }
}
