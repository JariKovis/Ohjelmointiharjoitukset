
public class HeiAdaLovelace {

    public static void main(String[] args) {
        String nimi = "Ada Lovelace";


    }
}
