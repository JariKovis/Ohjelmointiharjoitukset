
public class PassiJaHammasharja {

    public static void main(String[] args) {

        String viesti = "Passi ja hammaslanka";

        System.out.println(viesti);
    }
}
