
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("11-05.1 11-05.2 11-05.3")
public class HajautustauluTest {

    @Test
    public void eiTesteja() {

    }

}
