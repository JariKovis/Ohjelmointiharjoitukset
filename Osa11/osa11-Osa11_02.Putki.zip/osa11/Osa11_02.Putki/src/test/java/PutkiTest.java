
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("11-02")
public class PutkiTest {

    @Test
    public void eiTesteja() {

    }
}
