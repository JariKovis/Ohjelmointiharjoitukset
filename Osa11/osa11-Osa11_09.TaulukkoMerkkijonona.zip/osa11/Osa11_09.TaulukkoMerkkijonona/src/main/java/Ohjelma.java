
public class Ohjelma {

    public static void main(String[] args) {
        // Testaa metodiasi täällä
    }

}
