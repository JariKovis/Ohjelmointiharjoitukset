
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("11-04.1 11-04.2")
public class ListaTest {

    @Test
    public void eiTesteja() {

    }

}
