
import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("11-01")
public class PiiloTest {

    @Test
    public void eiTesteja() {

    }
}
