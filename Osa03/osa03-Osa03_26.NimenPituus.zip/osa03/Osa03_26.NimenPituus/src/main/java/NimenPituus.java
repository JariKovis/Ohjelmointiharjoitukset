
import java.util.Scanner;

public class NimenPituus {
    public static void main(String[] args) {
        Scanner lukija = new Scanner(System.in);
        // kutsu täältä metodiasi
    }
    
    // tee tänne metodi 
    // public static int laskeKirjaimet(String merkkijono)
    
}
