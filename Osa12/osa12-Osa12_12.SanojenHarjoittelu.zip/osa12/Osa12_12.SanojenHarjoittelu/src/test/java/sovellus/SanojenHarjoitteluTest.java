package sovellus;

import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.Test;

@Points("12-12")
public class SanojenHarjoitteluTest {

    @Test
    public void noTests() {

    }
}
