package sovellus;


// END SOLUTION
public class SanaharjoitteluSovellus {


    public static void main(String[] args) {
    }
}
