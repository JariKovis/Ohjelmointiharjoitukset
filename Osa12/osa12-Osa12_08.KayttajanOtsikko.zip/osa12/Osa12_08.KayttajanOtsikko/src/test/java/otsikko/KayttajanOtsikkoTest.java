package otsikko;

import fi.helsinki.cs.tmc.edutestutils.Points;
import org.junit.*;

@Points("12-08")
public class KayttajanOtsikkoTest {

    @Test
    public void noTests() {

    }

}
