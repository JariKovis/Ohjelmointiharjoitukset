package sovellus;

public class TervehtijaSovellus {


    public static void main(String[] args) {
        System.out.println("Hellow world!");
    }
}
