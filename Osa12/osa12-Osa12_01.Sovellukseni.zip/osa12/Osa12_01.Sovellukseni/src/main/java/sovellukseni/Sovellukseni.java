package sovellukseni;


public class Sovellukseni {
    

    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

}
