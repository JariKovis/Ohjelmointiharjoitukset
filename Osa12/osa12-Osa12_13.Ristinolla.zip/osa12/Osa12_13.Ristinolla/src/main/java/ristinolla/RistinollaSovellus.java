package ristinolla;


public class RistinollaSovellus {


    public static void main(String[] args) {
        System.out.println("Hello world!");
    }

}
