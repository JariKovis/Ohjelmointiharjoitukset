
public class Ohjelma {

    // päivitä tänne tieto tehtävän etenemisestä
    public static int osiaToteutettu() {
        return 0;
    }
}
