

public class Apu {

    public static Maa m(int m) {
        if (m == 0) {
            return Maa.RISTI;
        }

        if (m == 1) {
            return Maa.RUUTU;
        }

        if (m == 2) {
            return Maa.HERTTA;
        }

        return Maa.PATA;

    }

}
