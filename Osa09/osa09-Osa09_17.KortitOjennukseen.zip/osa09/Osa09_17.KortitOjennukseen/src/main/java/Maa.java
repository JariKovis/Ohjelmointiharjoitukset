

public enum Maa {
    RISTI, RUUTU, HERTTA, PATA;

}
