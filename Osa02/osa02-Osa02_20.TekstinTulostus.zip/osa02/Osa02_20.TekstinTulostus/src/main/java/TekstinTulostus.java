public class TekstinTulostus {

    public static void main(String[] args) {
        tulostaTeksti();
    }
    
    public static void tulostaTeksti() {
        // kirjoita koodia tähän
    }
}
